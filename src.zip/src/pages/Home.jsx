import { useEffect, useState } from "react"
import { supabase } from "../utils/client"
import PostCard from "../components/PostCard"

export default function Home() {
  const [posts, setPosts] = useState([])
  const [sortBy, setSortBy] = useState("created_at") // or "upvotes"
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    fetchPosts()
  }, [sortBy])

  async function fetchPosts() {
    const { data, error } = await supabase
      .from("posts")
      .select("*")
      .order(sortBy, { ascending: sortBy === "created_at" }) // newest first, upvotes descending
    if (data) setPosts(data)
  }

  const filteredPosts = posts.filter((post) =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase())
  )

  console.log("Posts from Supabase:", posts)

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-4">
      <h1 className="text-3xl font-bold mb-4">Handcrafter’s Hub Feed</h1>

      <div className="flex items-center gap-4 mb-4">
        <input
          type="text"
          placeholder="Search by title"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="border p-2 rounded w-full max-w-sm"
        />

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="border p-2 rounded"
        >
          <option value="created_at">Sort by Newest</option>
          <option value="upvotes">Sort by Upvotes</option>
        </select>
      </div>

      {filteredPosts.length === 0 ? (
        <p>No posts found.</p>
      ) : (
        filteredPosts.map((post) => <PostCard key={post.id} post={post} />)
      )}
    </div>
  )
}