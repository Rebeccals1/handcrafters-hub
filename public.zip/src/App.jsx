import { useEffect, useState } from 'react';
import { supabase } from './utils/client';
import { Link, Outlet } from 'react-router-dom';

function NavBar({ profile }) {
  return (
    <nav className="flex items-center justify-between p-4 bg-indigo-600 text-white">
      <Link to="/" className="text-xl font-bold">
        Handcrafter's Hub
      </Link>
      <div className="flex items-center gap-4">
        {profile ? (
          <>
            <span>{profile.full_name}</span>
            {profile.avatar_url && (
              <img
                src={profile.avatar_url}
                alt="Avatar"
                className="w-10 h-10 rounded-full"
              />
            )}
          </>
        ) : (
          <Link to="/login" className="underline">
            Log In
          </Link>
        )}
      </div>
    </nav>
  );
}

function App() {
  const [profile, setProfile] = useState(null);
  const [session, setSession] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) fetchProfile(session.user.id);
    });

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) fetchProfile(session.user.id);
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  async function fetchProfile(userId) {
    try {
      const { data, error, status } = await supabase
        .from('profiles')
        .select('full_name, avatar_url')
        .eq('id', userId)
        .single();

      if (error && status !== 406) throw error;

      if (data) setProfile(data);
    } catch (error) {
      console.error('Profile fetch error:', error.message);
    }
  }

  return (
    <div>
      <NavBar profile={profile} />
      <main className="main-content">
        {profile ? (
          <h2>Welcome, {profile.full_name}!</h2>
        ) : (
          <p>Loading profile...</p>
        )}
        <Outlet />
      </main>
    </div>
  );
}

export default App;
