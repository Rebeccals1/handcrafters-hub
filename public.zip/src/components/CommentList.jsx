import { useEffect, useState } from "react";
import { supabase } from "../utils/client";

export default function CommentList({ postId }) {
  const [comments, setComments] = useState([]);

  useEffect(() => {
    fetchComments();
  }, [postId]);

  const fetchComments = async () => {
    const { data, error } = await supabase
      .from("comments")
      .select(`
        id,
        content,
        created_at,
        user_id,
        profiles (
          full_name,
          avatar_url
        )
      `)
      .eq("post_id", postId)
      .order("created_at", { ascending: true });

    if (error) {
      console.error("Error fetching comments:", error.message);
    } else {
      setComments(data);
    }
  };

  return (
    <div className="comment-list">
      <h3>Comments</h3>
      {comments.length === 0 ? (
        <p>No comments yet.</p>
      ) : (
        comments.map(comment => (
          <div key={comment.id} className="comment-card">
            <div className="comment-header">
              {comment.profiles?.avatar_url && (
                <img
                  src={comment.profiles.avatar_url}
                  alt={`${comment.profiles.full_name}'s avatar`}
                  className="avatar"
                />
              )}
              <strong>{comment.profiles?.full_name || "Anonymous"}</strong>
              <span className="comment-date">
                {new Date(comment.created_at).toLocaleString()}
              </span>
            </div>
            <p>{comment.content}</p>
          </div>
        ))
      )}
    </div>
  );
}
