// components/CommentForm.jsx
import { useState } from 'react'
import { supabase } from '../utils/client'

const CommentForm = ({ postId, userId, onCommentAdded }) => {
  const [content, setContent] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!content) return

    const { error } = await supabase.from('comments').insert([
      { content, post_id: postId, user_id: userId }
    ])

    if (error) {
      console.error('Error adding comment:', error.message)
    } else {
      setContent('')
      onCommentAdded()
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <textarea
        placeholder="Add a comment..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        rows="3"
        required
      />
      <button type="submit">Post Comment</button>
    </form>
  )
}

export default CommentForm
