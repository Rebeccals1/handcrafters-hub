// 🔧 utils/ensureUserProfile.js
import { supabase } from './client.js';

export async function ensureUserProfile(user) {
  if (!user || !user.id) return;

  const { data: existing, error } = await supabase
    .from('profiles')
    .select('id') // 👈 make sure you're selecting valid column names
    .eq('id', user.id)
    .single();

  if (error && error.code !== 'PGRST116') {
    console.error('Error checking profile:', error.message);
    return false;
  }

  if (existing) return true; // ✅ Profile already exists

  const name =
    user.user_metadata?.name ||
    user.user_metadata?.full_name ||
    user.email ||
    'Unnamed User';

  const avatar_url = user.user_metadata?.avatar_url || '';

  const { error: insertError } = await supabase.from('profiles').insert([
    {
      id: user.id,
      name,
      avatar_url,
      email: user.email,
    },
  ]);

  if (insertError) {
    console.error('Failed to create user profile:', insertError.message);
    return false;
  }

  return true;
}
