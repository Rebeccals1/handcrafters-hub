// 🔧 components/PostCard.jsx
export default function PostCard({ post }) {
  return (
    <div className="post-card">
      <div className="post-author">
        <img
          src={post.profiles?.avatar_url || '/default-avatar.png'}
          alt="avatar"
          className="avatar"
        />
        <span>{post.profiles?.name || 'Anonymous'}</span>
      </div>
      <h3>{post.title}</h3>
      <p>{post.content}</p>
    </div>
  );
}