// 🔧 pages/NewPost.jsx
import { useEffect, useState } from 'react';
import { useNavigate, useOutletContext } from 'react-router-dom';
import { supabase } from '../utils/client';

export default function NewPost() {
  const { userId } = useOutletContext();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [userName, setUserName] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserName = async () => {
      if (!userId) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('name')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error fetching user name:', error.message);
      } else {
        setUserName(data?.name || 'Unnamed User');
      }
    };

    fetchUserName();
  }, [userId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title || !userId) return;

    setLoading(true);

    const { error } = await supabase.from('posts').insert([
      {
        title,
        content,
        user_id: userId,
        user_name: userName,
      },
    ]);

    setLoading(false);

    if (error) {
      console.error('Error posting:', error.message);
    } else {
      navigate('/');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="post-form">
      <h2>New Post by {userName ? userName : userId ? 'Unnamed User' : 'Loading...'}</h2>
      <input
        type="text"
        placeholder="Post title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <textarea
        placeholder="Content (optional)"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        rows="4"
      />
      <button type="submit" disabled={loading}>
        {loading ? 'Posting...' : 'Create Post'}
      </button>
    </form>
  );
}