import { useState } from 'react';
import { supabase } from '../utils/client';

const CommentForm = ({ postId, userId, onCommentAdded }) => {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content || !userId) return;

    setLoading(true);
    const { error } = await supabase.from('comments').insert([
      { content, post_id: postId, user_id: userId },
    ]);

    setLoading(false);
    if (error) {
      console.error('Error adding comment:', error.message);
    } else {
      setContent('');
      onCommentAdded();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="comment-form">
      <textarea
        placeholder="Add a comment..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        rows="3"
        required
      />
      <button className="button" type="submit" disabled={loading}>
        {loading ? 'Posting...' : 'Post Comment'}
      </button>
    </form>
  );
};

export default CommentForm;
