export default function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 Handcrafter’s Hub. Built with love and creativity.</p>
    </footer>
  );
}
