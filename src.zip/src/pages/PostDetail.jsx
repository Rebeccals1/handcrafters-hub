import { useOutletContext, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { supabase } from '../utils/client';
import CommentForm from '../components/CommentForm';
import CommentList from '../components/CommentList';

const PostDetail = () => {
  const { userId } = useOutletContext();
  const { id } = useParams();
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    const fetchPost = async () => {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('id', id)
        .single();
      if (!error) setPost(data);
    };

    const fetchComments = async () => {
      const { data, error } = await supabase
        .from('comments')
        .select('*')
        .eq('post_id', id)
        .order('created_at', { ascending: false });
      if (!error) setComments(data);
    };

    fetchPost();
    fetchComments();
  }, [id, refreshKey]);

  const handleCommentAdded = () => {
    setRefreshKey(prev => prev + 1);
  };

  if (!post) return <p>Loading...</p>;

  return (
    <div className="post-card">
      <h1 className="post-title">{post.title}</h1>
      <p className="post-content">{post.content}</p>
      {post.image_url && <img src={post.image_url} alt="Post" className="post-image" />}
      
      <CommentForm postId={post.id} onCommentAdded={handleCommentAdded} />
      <CommentList comments={comments} />
    </div>
  );
};

export default PostDetail;
