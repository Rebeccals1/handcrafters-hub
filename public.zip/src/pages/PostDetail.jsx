// pages/PostDetail.jsx
import { useOutletContext, useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { supabase } from '../utils/client'
import CommentForm from '../components/CommentForm'
import CommentList from '../components/CommentList'

const PostDetail = () => {
  const { userId } = useOutletContext()
  const { id } = useParams()
  const [post, setPost] = useState(null)
  const [refreshKey, setRefreshKey] = useState(0)

  const fetchPost = async () => {
    const { data, error } = await supabase
      .from('posts')
      .select('*')
      .eq('id', id)
      .single()
    if (!error) setPost(data)
  }

  useEffect(() => {
    fetchPost()
  }, [id])

  const handleCommentAdded = () => {
    setRefreshKey(prev => prev + 1)
  }

  if (!post) return <p>Loading...</p>

  return (
    <div>
      <h1>{post.title}</h1>
      <p>{post.content}</p>
      {post.image_url && <img src={post.image_url} alt="Post" width="300" />}

      <CommentForm
        postId={post.id}
        userId={userId}
        onCommentAdded={handleCommentAdded}
      />
      <CommentList postId={post.id} refreshKey={refreshKey} />
    </div>
  )
}

export default PostDetail
