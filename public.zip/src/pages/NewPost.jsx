import { useState } from "react"
import { useNavigate, useOutletContext } from "react-router-dom"
import { supabase } from "../utils/client"

const NewPost = () => {
  const { userId } = useOutletContext()
  const navigate = useNavigate()

  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [flag, setFlag] = useState("")
  const [category, setCategory] = useState("")
  const [error, setError] = useState("")

  async function handleSubmit(e) {
    e.preventDefault()

    if (!title.trim()) {
      setError("Title is required.")
      return
    }

    const { error } = await supabase.from("posts").insert([
      {
        title,
        content,
        image_url: imageUrl,
        flags: flag ? [flag] : null,
        category,
        user_id: userId,
      },
    ])

    if (error) {
      console.error("Insert failed:", error.message)
      setError(error.message)
    } else {
      navigate("/")
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-xl mx-auto p-4">
      <h2 className="text-xl font-bold">Create Post</h2>
      {error && <p className="text-red-600">{error}</p>}
      <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" required className="border p-2 w-full" />
      <textarea value={content} onChange={e => setContent(e.target.value)} placeholder="Content" className="border p-2 w-full mt-2" />
      <input type="text" value={imageUrl} onChange={e => setImageUrl(e.target.value)} placeholder="Image URL" className="border p-2 w-full mt-2" />
      <select value={flag} onChange={e => setFlag(e.target.value)} className="border p-2 w-full mt-2">
        <option value="">No Flag</option>
        <option value="Question">Question</option>
        <option value="Opinion">Opinion</option>
      </select>
      <input type="text" value={category} onChange={e => setCategory(e.target.value)} placeholder="Category" className="border p-2 w-full mt-2" />
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 mt-4">Submit</button>
    </form>
  )
}

export default NewPost
