import { Link } from "react-router-dom"

export default function PostCard({ post }) {
  return (
    <div className="border p-4 rounded bg-white shadow">
      <Link to={`/post/${post.id}`}>
        <h2 className="text-xl font-bold text-blue-600 hover:underline">{post.title}</h2>
      </Link>
      <p className="text-sm text-gray-500">
        Posted on {new Date(post.created_at).toLocaleDateString()}
      </p>
      <p className="text-sm font-semibold">👍 {post.upvotes}</p>
    </div>
  )
}
