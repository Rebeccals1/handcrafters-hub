export default function CommentList({ comments }) {
  return (
    <div className="comment-section">
      <h3>Comments</h3>
      {comments.length === 0 ? (
        <p>No comments yet.</p>
      ) : (
        comments.map((comment) => (
          <div key={comment.id} className="comment">
            <div className="flex items-center gap-2 mb-1">
              {comment.profiles?.avatar_url && (
                <img
                  src={comment.profiles.avatar_url}
                  alt="Avatar"
                  className="w-8 h-8 rounded-full"
                />
              )}
              <strong>{comment.profiles?.full_name || 'Anonymous'}</strong>
              <span className="text-sm text-gray-500">
                {new Date(comment.created_at).toLocaleString()}
              </span>
            </div>
            <p>{comment.content}</p>
          </div>
        ))
      )}
    </div>
  );
}
